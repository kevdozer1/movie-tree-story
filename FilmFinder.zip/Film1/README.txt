README:

CONTRIBUTORS:
Cameron Rogers (cfrogers@wisc.edu) xteam 203
Kevin Hopkins (khopkins4@wisc.edu) xteam 203

FilmFinder is a sleek movie recommendation tool that parses a set of a variety of movies according to the user's inputs.

[Data instructions: data is read from pre-existing spreadsheet]

[Build instructions: all files should be contained in FilmFinder folder]

[Special instructions: none]

For reference, here is a general overview of how the FilmFinder application works:

1) Import movies and details from https://www.kaggle.com/carolzhangdc/imdb-5000-movie-dataset or similar DB into arrays in program
2) Ask questions to end user and assign each movie a score based on those answers.
3) Return the highest rated movie(s) to the user

This system is sleek and functional, not complicating a process that is advertised to be a quick tool to help the user.

Bug Report: input validation to be made more robust

Future Work: fix above bugs, improve aesthetic quality, provide ability for user to input their own movie dataset
