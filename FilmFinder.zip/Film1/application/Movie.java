/** Movie.java created by camro on CAM_PC in FilmFinder
 *
 * Author:	Cameron Rogers (cfrogers@wisc.edu)
 * Date:	@date
 * 
 * Course:	CS400
 * Year:	Spring 2020
 * Lecture: 002
 * 
 * IDE:		Eclipse IDE for Java Developers
 *
 * List Collaborators: Kevin Hopkins (khopkins4@wisc.edu)
 *
 * Other credits: Other sources or info
 *
 * Known bugs: Describe unresolved errors
 */
package application;

/**
 * Movie - Represents the movies that are recommended to the user and their attributes
 * @author camro
 * @author kevinh
 *
 */
public class Movie implements Comparable<Movie> {

    String movieTitle;
    String directorName;
    String [] actorNames;
    String [] genres;
    double gross;
    String [] plotKeywords;
    int titleYear;
    String contentRating;
    String imdbLink;
    String country;
    String language;
    double imdbScore;
    double budget;
    int filmFinderScore;
    int durationMinutes;
    
    /**
     * Instantiates a new Movie object
     * 
     * @param movieTitle    title of the movie
     * @param directorName  name of director
     * @param actor1        name of an actor
     * @param actor2        name of an actor
     * @param actor3        name of an actor
     * @param genres        genres that describe the movie
     * @param gross         grossing amount
     * @param plotKeywords  keywords that describe the plot
     * @param year          year of release
     * @param IMDBLink      link to IMDb page
     * @param contentRating age rating(PG, PG-13, R..)
     * @param country       country of origin
     * @param budget        budget to make film
     * @param durationMinutes   duration of the movie in minutes
     * @param IMDBScore     score out of 10 received from IMDb
     * @param language      spoken language in film
     * 
     */
    public Movie(String movieTitle, String directorName, String actor1, String actor2, String actor3, 
        String genres, String gross, String plotKeywords, String year, String IMDBLink, String contentRating, 
        String country, String budget, String durationMinutes, String IMDBScore, String language) {
        
        this.movieTitle = movieTitle;
        this.directorName = directorName;
        this.actorNames = new String[]{actor1, actor2, actor3};
        this.genres = genres.split("\\|");
        if(gross.length() > 0) this.gross = Double.parseDouble(gross);
        this.plotKeywords = plotKeywords.split("\\|");
        if(year.length() > 0) this.titleYear = Integer.parseInt(year);
        this.imdbLink = IMDBLink;
        this.contentRating = contentRating;
        this.country = country;
        if(budget.length() > 0) this.budget = Double.parseDouble(budget);
        if(durationMinutes.length() > 0) this.durationMinutes = Integer.parseInt(durationMinutes);
        if(IMDBScore.length() > 0) this.imdbScore = Double.parseDouble(IMDBScore);
        this.language = language;
        this.filmFinderScore = 0;
    }
    
    /**
     * Increments the filmFinderScore of the Movie by an int score
     * 
     * @param score - amount to increment score by
     */
    public void incrementScore(int score) {
        this.filmFinderScore += score;
    }
    /**
     * @param args
     */
    public static void main(String[] args) {
        
    }

    /**
     * Compares the filmFinderScore of this Movie to another and returns the difference
     * 
     * @param o - Movie object to be compared to
     * @returns the difference in the filmFinderScore variables of the two
     */
    @Override
    public int compareTo(Movie o) {
        return (o.filmFinderScore - filmFinderScore);
    }

}
