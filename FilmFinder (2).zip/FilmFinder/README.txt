README:
This is a very basic example of our interface. We are working on a way to let the user choose the number of questions,
and past that we have not yet finished our Movie ADT. As such, alot of the aestetics have not been completed yet
as they rely on the Movie ADT. For example, we plan on getting an image from the top contender of movie, which
relies on the IMDB id from our data csv. As such we still have a lot to do before our image of the final result
becomes visible to you.

For reference, here's a short summary of how our program will work, a TLDR of sorts from our design doc:

1) Import movies and details from https://www.kaggle.com/carolzhangdc/imdb-5000-movie-dataset or similar DB into arrays in program
2) Ask questions to end user and assign each movie a score based on those answers.
3) Return the highest rated movie(s) to the user

Because we require this info, our aesthetic is bland and not fully functional for different movies.
We intend to use spinners and some variety for questions, but as of now we can't show this 