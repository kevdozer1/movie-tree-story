/**
 * Main.java created by camro on CAM_PC in FilmFinder
 *
 * Author:	Cameron Rogers (cfrogers@wisc.edu)
 * Date:	@date
 * 
 * Course:	CS400
 * Year:	Spring 2020
 * Lecture: 002
 * 
 * IDE:		Eclipse IDE for Java Developers
 *
 * List Collaborators: Name, email@wisc.edu, lecture number
 *
 * Other credits: Other sources or info
 *
 * Known bugs: Describe unresolved errors
 */
package application;

import java.util.List;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Main2 extends Application {
    
    Stage window; // StartScreen
    Scene start,q1,q2,q3,q4,q5,end; // Question scenes
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        window = primaryStage;
        
        // STARTSCREEN LAYOUT
        Label welcomeLabel = new Label("Welcome to FilmFinder! Choose an option!");
        Button findFilm = new Button("Find something to watch");
        findFilm.setOnAction(e -> window.setScene(q1));
        
        //Spinner s = new Spinner(5,10,5); // Question amount NOT YET IMPLEMENTED
        
        VBox layout1 = new VBox(20);
        layout1.getChildren().addAll(welcomeLabel, findFilm);
        start = new Scene(layout1, 360, 640);
        
        // Question elements 
        Label question;
        VBox questionLayout;
        
        
        // QUESTION 1 LAYOUT AND ACTIONS
        question = new Label("Insert question 1 here");
        
        Button retStart1 = new Button("Return to start");
        retStart1.setOnAction(e -> window.setScene(start));
        
        Button yes1 = new Button("yes");
        Button no1 = new Button("no");
        yes1.setOnAction(e -> window.setScene(q2));
        no1.setOnAction(e -> window.setScene(q2));
        
        questionLayout = new VBox(20);
        questionLayout.getChildren().addAll(question, yes1, no1, retStart1);
        q1 = new Scene(questionLayout, 360, 640);
        
        // QUESTION 2 LAYOUT AND ACTIONS
        question = new Label("Insert question 2 here");
        
        Button retStart2 = new Button("Return to start");
        retStart2.setOnAction(e -> window.setScene(start));
        
        Button yes2 = new Button("yes");
        Button no2 = new Button("no");
        yes2.setOnAction(e -> window.setScene(q3));
        no2.setOnAction(e -> window.setScene(q3));
        
        questionLayout = new VBox(20);
        questionLayout.getChildren().addAll(question, yes2, no2, retStart2);
        q2 = new Scene(questionLayout, 360, 640);
        
        // QUESTION 3 LAYOUT AND ACTIONS
        question = new Label("Insert question 3 here");
        
        Button retStart3 = new Button("Return to start");
        retStart3.setOnAction(e -> window.setScene(start));
        
        Button yes3 = new Button("yes");
        Button no3 = new Button("no");
        yes3.setOnAction(e -> window.setScene(q4));
        no3.setOnAction(e -> window.setScene(q4));
        
        questionLayout = new VBox(20);
        questionLayout.getChildren().addAll(question, yes3, no3, retStart3);
        q3 = new Scene(questionLayout, 360, 640);
        
        // QUESTION 4 LAYOUT AND ACTIONS
        question = new Label("Insert question 4 here");
        
        Button retStart4 = new Button("Return to start");
        retStart4.setOnAction(e -> window.setScene(start));
        
        Button yes4 = new Button("yes");
        Button no4 = new Button("no");
        yes4.setOnAction(e -> window.setScene(q5));
        no4.setOnAction(e -> window.setScene(q5));
        
        questionLayout = new VBox(20);
        questionLayout.getChildren().addAll(question, yes4, no4, retStart4);
        q4 = new Scene(questionLayout, 360, 640);
        
        // QUESTION 5 LAYOUT AND ACTIONS
        question = new Label("Insert question 5 here");
        
        Button retStart5 = new Button("Return to start");
        retStart5.setOnAction(e -> window.setScene(start));
        
        Button yes5 = new Button("yes");
        Button no5 = new Button("no");
        yes5.setOnAction(e -> window.setScene(end));
        no5.setOnAction(e -> window.setScene(end));
        
        questionLayout = new VBox(20);
        questionLayout.getChildren().addAll(question, yes5, no5, retStart5);
        q5 = new Scene(questionLayout, 360, 640);
        
        // ENDSCREEN LAYOUT AND ACTIONS
        question = new Label("I think you would like...");
        
        Button retStartEnd = new Button("Return to start");
        retStartEnd.setOnAction(e -> window.setScene(start));
        
        Label movie = new Label("The Dark Knight"); // Sample result movie
        
        questionLayout = new VBox(20);
        questionLayout.getChildren().addAll(question, movie, retStartEnd);
        end = new Scene(questionLayout, 360, 640);
        
        // Start scene at startScreen
        window.setScene(start);
        window.setTitle("FILMFINDER");
        window.show();
        
        
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        launch(args);
    }
}