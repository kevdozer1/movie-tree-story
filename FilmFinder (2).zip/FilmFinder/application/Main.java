/**
 * Main.java created by camro on CAM_PC in FilmFinder
 *
 * Author:	Cameron Rogers (cfrogers@wisc.edu)
 * Date:	@date
 * 
 * Course:	CS400
 * Year:	Spring 2020
 * Lecture: 002
 * 
 * IDE:		Eclipse IDE for Java Developers
 *
 * List Collaborators: Name, email@wisc.edu, lecture number
 *
 * Other credits: Other sources or info
 *
 * Known bugs: Describe unresolved errors
 */
package application;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class Main extends Application {
    static ArrayList<Movie> filmArr = new ArrayList<Movie>(); // Arraylist of all movies parsed from file
    
    
    
    
    
    static ArrayList<Question> basicQArr = new ArrayList<Question>(); // Questions to get baseline
    static ArrayList<Question> narrowQArr = new ArrayList<Question>(); // Questions to narrow down
    int numResult = -1;
    
    private static class Question {
        Label questionLabel = new Label();
        ArrayList<Button> buttons = new ArrayList<Button>();
        
        public Question(String l) {
            questionLabel.setText(l);
        }
    }
    ///////////////////////////////////////////////////////////////////////////////
    // ALL QUESTIONS HERE
    ///////////////////////////////////////////////////////////////////////////////
    
    public static void setQuestions() {
        // Buttons for reuse
        Button yes = new Button("yes");
        Button no = new Button("no");
        
        // Questions
        Question last10 = new Question("Would you like a movie from the past 10 years?");
        last10.buttons.add(yes);
        yes.setOnAction(e -> {
            for(Movie m : filmArr) {
                if(2020 - m.titleYear < 10) {
                    m.incrementScore(1);
                }
            }
            System.out.print("yes1");
        });
        
        Question IMDBScore = new Question("Would you like a movie with an IMDB score above 4.5?");
        IMDBScore.buttons.add(yes);
        yes.setOnAction(e -> {
            for(Movie m : filmArr) {
                if(m.imdbScore * 10 > 45 ) {
                    m.incrementScore(1);
                }
            }
            System.out.print("yes2");
        });
        
        basicQArr.add(last10);
        basicQArr.add(IMDBScore);
    }
    
    
    
    
    
    
    
    
    
    ///////////////////////////////////////////////////////////////////////////////
    // JAVA FX CODE
    ///////////////////////////////////////////////////////////////////////////////
     
    Stage window; // StartScreen
    Scene start,q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,end; // Question scenes
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        window = primaryStage;
        
        // STARTSCREEN LAYOUT
        Label welcomeLabel = new Label("Welcome to FilmFinder! Choose an option!");
        Button findFilm = new Button("Find something to watch");
        findFilm.setOnAction(e -> window.setScene(q1));
        
        VBox layout1 = new VBox(20);
        layout1.getChildren().addAll(welcomeLabel, findFilm);
        start = new Scene(layout1, 360, 640);
        
        // Question elements 
        Label question;
        VBox questionLayout;
        
        // BASIC YES NO QUESTIONS
        // QUESTION 1 LAYOUT AND ACTIONS
        question = new Label("Would you like a movie from the past 10 years?");
        
        Button retStart1 = new Button("Return to start");
        retStart1.setOnAction(e -> cleanUp());
        
        Button yes1 = new Button("yes");
        Button no1 = new Button("no");
        Button np1 = new Button("No preference");
        
        yes1.setOnAction(e -> {
            for(Movie m : filmArr) {
                if(2020 - m.titleYear <= 10) {
                    m.incrementScore(1);
                }
            }
            window.setScene(q2);
        });
        no1.setOnAction(e -> {
            for(Movie m : filmArr) {
                if(2020 - m.titleYear > 10) {
                    m.incrementScore(1);
                }
            }
            window.setScene(q2);
        });
        np1.setOnAction(e -> window.setScene(q2));
        
        questionLayout = new VBox(20);
        questionLayout.getChildren().addAll(question, yes1, no1, np1, retStart1);
        q1 = new Scene(questionLayout, 360, 640);
        
        // QUESTION 2 LAYOUT AND ACTIONS
        
        question = new Label("Would you like a movie with an IMDB score above 7.5?");
        
        Button retStart2 = new Button("Return to start");
        retStart2.setOnAction(e -> cleanUp());
        
        Button yes2 = new Button("yes");
        Button no2 = new Button("no");
        Button np2 = new Button("No preference");
        
        yes2.setOnAction(e -> {
            for(Movie m : filmArr) {
                if(m.imdbScore * 10 > 75 ) {
                    m.incrementScore(1);
                }
            }
            window.setScene(q3);
        });
        no2.setOnAction(e -> {
            for(Movie m : filmArr) {
                if(m.imdbScore * 10 < 75 ) {
                    m.incrementScore(1);
                }
            }
            window.setScene(q3);
        });
        np2.setOnAction(e -> window.setScene(q3));
        
        questionLayout = new VBox(20);
        questionLayout.getChildren().addAll(question, yes2, no2, np2, retStart2);
        q2 = new Scene(questionLayout, 360, 640);
        
        // QUESTION 3 LAYOUT AND ACTIONS
        question = new Label("Would you like a movie made in the USA?");
        
        Button retStart3 = new Button("Return to start");
        retStart3.setOnAction(e -> cleanUp());
        
        Button yes3 = new Button("yes");
        Button no3 = new Button("no");
        Button np3 = new Button("No preference");
        
        yes3.setOnAction(e -> {
            for(Movie m : filmArr) {
                if(m.country.equals("USA")) {
                    m.incrementScore(1);
                }
            }
            window.setScene(q4);
        });
        no3.setOnAction(e -> {
            for(Movie m : filmArr) {
                if(!m.country.equals("USA")) {
                    m.incrementScore(1);
                }
            }
            window.setScene(q4);
        });
        np3.setOnAction(e -> window.setScene(q4));
        
        questionLayout = new VBox(20);
        questionLayout.getChildren().addAll(question, yes3, no3, np3, retStart3);
        q3 = new Scene(questionLayout, 360, 640);
        
        // QUESTION 4 LAYOUT AND ACTIONS
        question = new Label("Would you like a movie in a language other than English?");
        
        Button retStart4 = new Button("Return to start");
        retStart4.setOnAction(e -> cleanUp());
        
        Button yes4 = new Button("yes");
        Button no4 = new Button("no");
        Button np4 = new Button("No preference");
        
        yes4.setOnAction(e -> {
            for(Movie m : filmArr) {
                if(!m.language.equals("English")) {
                    m.incrementScore(1);
                }
            }
            window.setScene(q5);
        });
        no4.setOnAction(e -> {
            for(Movie m : filmArr) {
                if(m.language.equals("English")) {
                    m.incrementScore(1);
                }
            }
            window.setScene(q5);
        });
        np4.setOnAction(e -> window.setScene(q5));
        
        questionLayout = new VBox(20);
        questionLayout.getChildren().addAll(question, yes4, no4, np4, retStart4);
        q4 = new Scene(questionLayout, 360, 640);
        
        // QUESTION 5 LAYOUT AND ACTIONS
        question = new Label("Would you like a movie longer than 2 hours?");
        
        Button retStart5 = new Button("Return to start");
        retStart5.setOnAction(e -> cleanUp());
        
        Button yes5 = new Button("yes");
        Button no5 = new Button("no");
        Button np5 = new Button("No preference");
        
        yes5.setOnAction(e -> {
            for(Movie m : filmArr) {
                if(m.durationMinutes >= 120) {
                    m.incrementScore(1);
                }
            }
            window.setScene(q6);
        });
        no5.setOnAction(e -> {
            for(Movie m : filmArr) {
                if(m.durationMinutes < 120) {
                    m.incrementScore(1);
                }
            }
            window.setScene(q6);
        });
        np5.setOnAction(e -> window.setScene(q6));
        
        questionLayout = new VBox(20);
        questionLayout.getChildren().addAll(question, yes5, no5, np5, retStart5);
        q5 = new Scene(questionLayout, 360, 640);
        
        
        
        // DEEPER NARROWING QUESTIONS       
        // QUESTION 6 LAYOUT AND ACTIONS
        question = new Label("What content rating would you prefer?");
        
        Button retStart6 = new Button("Return to start");
        retStart6.setOnAction(e -> cleanUp());
        
        Button b1op1 = new Button("G");
        Button b1op2 = new Button("PG");
        Button b1op3 = new Button("PG-13");
        Button b1op4 = new Button("R");
        Button b1op5 = new Button("No preference");

        b1op1.setOnAction(e -> {
            for(Movie m : filmArr) {
                if(m.contentRating.equals("G")) {
                    m.incrementScore(1);
                }
            }
            window.setScene(q7);
        });
        
        b1op2.setOnAction(e -> {
            for(Movie m : filmArr) {
                if(m.contentRating.equals("PG")) {
                    m.incrementScore(1);
                }
            }
            window.setScene(q7);
        });
        
        b1op3.setOnAction(e -> {
            for(Movie m : filmArr) {
                if(m.contentRating.equals("PG-13")) {
                    m.incrementScore(1);
                }
            }
            window.setScene(q7);
        });
        
        b1op4.setOnAction(e -> {
            for(Movie m : filmArr) {
                if(m.contentRating.equals("R")) {
                    m.incrementScore(1);
                }
            }
            window.setScene(q7);
        });
        
        b1op5.setOnAction(e -> window.setScene(q7));
        
        
        
        questionLayout = new VBox(20);
        questionLayout.getChildren().addAll(question, b1op1, b1op2, b1op3, b1op4, b1op5, retStart6);
        q6 = new Scene(questionLayout, 360, 640);
        
        // QUESTION 7 LAYOUT AND ACTIONS
        question = new Label("Which of these Genres would you prefer?");
        
        Button retStart7 = new Button("Return to start");
        retStart7.setOnAction(e -> cleanUp());
        
        Button b2op1 = new Button("Action");
        Button b2op2 = new Button("Adventure");
        Button b2op3 = new Button("Romance");
        Button b2op4 = new Button("Drama");
        Button b2op5 = new Button("Biography");
        Button b2op6 = new Button("Comedy");
        Button b2op7 = new Button("Thriller");
        Button b2op8 = new Button("Sci-Fi");
        Button b2op9 = new Button("Horror");
        Button b2op10 = new Button("Mystery");
        Button b2op11 = new Button("Crime");
        Button b2op12 = new Button("Music");

        b2op1.setOnAction(e -> {
            for(Movie m : filmArr) {
                for(int i = 0; i < m.genres.length; i++) {
                    if(m.genres[i].equals("Action")) {
                        m.incrementScore(1);
                    }
                }
            }
            window.setScene(q8);
        });
        
        b2op2.setOnAction(e -> {
            for(Movie m : filmArr) {
                for(int i = 0; i < m.genres.length; i++) {
                    if(m.genres[i].equals("Adventure")) {
                        m.incrementScore(1);
                    }
                }
            }
            window.setScene(q8);
        });
        
        b2op3.setOnAction(e -> {
            for(Movie m : filmArr) {
                for(int i = 0; i < m.genres.length; i++) {
                    if(m.genres[i].equals("Romance")) {
                        m.incrementScore(1);
                    }
                }
            }
            window.setScene(q8);
        });
        
        b2op4.setOnAction(e -> {
            for(Movie m : filmArr) {
                for(int i = 0; i < m.genres.length; i++) {
                    if(m.genres[i].equals("Drama")) {
                        m.incrementScore(1);
                    }
                }
            }
            window.setScene(q8);
        });
        
        b2op5.setOnAction(e -> {
            for(Movie m : filmArr) {
                for(int i = 0; i < m.genres.length; i++) {
                    if(m.genres[i].equals("Biography")) {
                        m.incrementScore(1);
                    }
                }
            }
            window.setScene(q8);
        });
        
        b2op6.setOnAction(e -> {
            for(Movie m : filmArr) {
                for(int i = 0; i < m.genres.length; i++) {
                    if(m.genres[i].equals("Comedy")) {
                        m.incrementScore(1);
                    }
                }
            }
            window.setScene(q8);
        });
        
        b2op7.setOnAction(e -> {
            for(Movie m : filmArr) {
                for(int i = 0; i < m.genres.length; i++) {
                    if(m.genres[i].equals("Thriller")) {
                        m.incrementScore(1);
                    }
                }
            }
            window.setScene(q8);
        });
        
        b2op8.setOnAction(e -> {
            for(Movie m : filmArr) {
                for(int i = 0; i < m.genres.length; i++) {
                    if(m.genres[i].equals("Sci-Fi")) {
                        m.incrementScore(1);
                    }
                }
            }
            window.setScene(q8);
        });
        
        b2op9.setOnAction(e -> {
            for(Movie m : filmArr) {
                for(int i = 0; i < m.genres.length; i++) {
                    if(m.genres[i].equals("Horror")) {
                        m.incrementScore(1);
                    }
                }
            }
            window.setScene(q8);
        });
        
        b2op10.setOnAction(e -> {
            for(Movie m : filmArr) {
                for(int i = 0; i < m.genres.length; i++) {
                    if(m.genres[i].equals("Mystery")) {
                        m.incrementScore(1);
                    }
                }
            }
            window.setScene(q8);
        });
        
        b2op11.setOnAction(e -> {
            for(Movie m : filmArr) {
                for(int i = 0; i < m.genres.length; i++) {
                    if(m.genres[i].equals("Crime")) {
                        m.incrementScore(1);
                        Collections.sort(filmArr); // Next questions require relativey sorted list
                    }
                }
            }
            window.setScene(q8);
        });
        
        b2op12.setOnAction(e -> {
            for(Movie m : filmArr) {
                for(int i = 0; i < m.genres.length; i++) {
                    if(m.genres[i].equals("Music")) {
                        m.incrementScore(1);
                        Collections.sort(filmArr); // Next questions require relatively sorted list
                    }
                }
            }
            window.setScene(q8);
        });
        

        
        
        questionLayout = new VBox(20);
        questionLayout.getChildren().addAll(question, b2op1, b2op2, b2op3, b2op4, b2op5, b2op6, b2op7, b2op8, b2op9, b2op10, b2op11, b2op12, retStart7);
        q7 = new Scene(questionLayout, 360, 640);
        
        // QUESTION 8 LAYOUT AND ACTIONS
        question = new Label("Which of these actors do you like best?   ");
        
        Button retStart8 = new Button("Return to start");
        retStart8.setOnAction(e -> cleanUp());
        
        ArrayList<String> actorList = new ArrayList<String>(); // Stores top 20ish actors
        for(Movie m : filmArr) {
            if(actorList.size() < 20) { // Dont want too many actors
                for(String actor : m.actorNames) {
                    actorList.add(actor);
                }
            }
        }
        
        GridPane grid = new GridPane();
        grid.add(question, 0, 0);
        
        for(int i = 0; i < 20; i++) {
            Button actorButton = new Button(actorList.get(i)); // At this point, we figured out how to make buttons much more efficiently!
            if(i < 10) {
                grid.add(actorButton, 0, i+1);
            } else {
                grid.add(actorButton, 1, i+1-10);
            }
            actorButton.setOnAction(e -> {
                for(Movie m : filmArr) {
                    for(String aname : m.actorNames) {
                        if(actorButton.getText().equals(aname)) {
                            m.incrementScore(1);
                        }
                    }
                }
                window.setScene(q9);
            });
        }
        
        Button np8 = new Button("No Preference");
        np8.setOnAction(e -> window.setScene(q9));
        grid.add(np8, 0, 13);
        
        grid.add(retStart8, 1, 0);
        q8 = new Scene(grid, 360, 640);
        
        // QUESTION 9 LAYOUT AND ACTIONS
        question = new Label("Which director do you like best?");
        
        Button retStart9 = new Button("Return to start");
        retStart9.setOnAction(e -> cleanUp());
        
        ArrayList<String> dirList = new ArrayList<String>();
        for(Movie m : filmArr) {
            if(dirList.size() < 12) { // Dont want too many directors
                dirList.add(m.directorName);
            }
        }
        questionLayout = new VBox(20);
        questionLayout.getChildren().add(question);
        
        for(int i = 0; i < 12; i++) {
            Button dirButton = new Button(dirList.get(i)); // At this point, we figured out how to make buttons much more efficiently!
            questionLayout.getChildren().add(dirButton);
            dirButton.setOnAction(e -> {
                for(Movie m : filmArr) {
                    if(dirButton.getText().equals(m.directorName)) {
                        m.incrementScore(1);
                    }
                }
                window.setScene(q10);
            });
        }
        
        Button np9 = new Button("No preference");
        np9.setOnAction(e -> window.setScene(q10));
        questionLayout.getChildren().addAll(np9, retStart9);
        q9 = new Scene(questionLayout, 360, 640);

        // QUESTION 10 LAYOUT AND ACTIONS
        question = new Label("What plot elements are best?   ");
        
        Button retStart10 = new Button("Return to start");
        retStart10.setOnAction(e -> cleanUp());
        
        ArrayList<String> plotKeys = new ArrayList<String>(); // Stores top 20ish actors
        for(Movie m : filmArr) {
            if(plotKeys.size() < 20) { // Dont want too many actors
                for(String key : m.plotKeywords) {
                    plotKeys.add(key);
                }
            }
        }
        
        GridPane grid2 = new GridPane();
        grid2.add(question, 0, 0);
        grid2.add(retStart10, 1, 0);
        
        for(int i = 0; i < 20; i++) {
            Button plot = new Button(plotKeys.get(i)); // At this point, we figured out how to make buttons much more efficiently!
            if(i < 10) {
                grid2.add(plot, 0, i+1);
            } else {
                grid2.add(plot, 1, i+1-10);
            }
            plot.setOnAction(e -> {
                for(Movie m : filmArr) {
                    for(String p : m.plotKeywords) {
                        if(plot.getText().equals(p)) {
                            m.incrementScore(1);
                            
                        }
                    }
                }
                Collections.sort(filmArr);
                window.setScene(end);
            });
        }
        
        q10 = new Scene(grid2, 360, 640);
        // ENDSCREEN LAYOUT AND ACTIONS
        question = new Label("I think you would like...");
        
        Button retStartEnd = new Button("Return to start");
        retStartEnd.setOnAction(e -> cleanUp());
        
        Collections.sort(filmArr);
         
        Label movie = new Label("Click the button for the best match!");
        
        Button getNextMovie = new Button("Get best match");
        
        getNextMovie.setOnAction(e -> {
            numResult++;
            movie.setText(filmArr.get(numResult).movieTitle);
            
        });
        
        Button saveList = new Button("Save results to file");
        saveList.setOnAction(e -> {
            PrintWriter pw;
            try {
                pw = new PrintWriter(new FileOutputStream("results.txt"));
                Collections.sort(filmArr);
                for (Movie m : filmArr) {
                    pw.println(m.movieTitle + ", " + m.titleYear);
                }
                pw.close();
            } catch (FileNotFoundException e1) {
                e1.printStackTrace();
            }      
        });
        
        questionLayout = new VBox(20);
        questionLayout.getChildren().addAll(question, movie, saveList, getNextMovie, retStartEnd);
        end = new Scene(questionLayout, 360, 640);
        
        // Start scene at startScreen
        window.setScene(start);
        window.setTitle("FILMFINDER");
        window.show();
        
        
    }
    
    /**
     * Returns to start of program
     */
    public void cleanUp() {
        for(Movie m : filmArr) {
            m.filmFinderScore = 0;
            window.setScene(start);
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////////
    // FILE PARSING
    ///////////////////////////////////////////////////////////////////////////////

    public static void getFromCSV() {
        String file = "movie_metadata.csv";
        String line = "";

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {

            while ((line = br.readLine()) != null) {

                /*
                 * ARRAY KEY
                 * 0: Color
                 * 1: Director Name
                 * 2: Num Critic for Review
                 * 3: Duration (Minutes)
                 * 4: Director FB Likes
                 * 5: Actor 3 FB Likes
                 * 6: Actor 2 Name
                 * 7: Actor 1 FB Likes
                 * 8: Gross
                 * 9: Genres
                 * 10: Actor 1 Name
                 * 11: Movie Title
                 * 12: Nom Voters
                 * 13: Cast Total FB Likes
                 * 14: Actor 3 Name
                 * 15: Face Number in Poster
                 * 16: Plot Keywords
                 * 17: IMDB Link
                 * 18: Num Users for Reviews
                 * 19: Language
                 * 20: Country
                 * 21: Content Rating
                 * 22: Budget
                 * 23: Title Year
                 * 24: Actor 2 FB Likes
                 * 25: IMDB Score
                 * 26: Aspect ratio
                 * 27: Movie FB Likes
                 */
                String[] details = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1); // Thank you https://stackoverflow.com/questions/1757065/java-splitting-a-comma-separated-string-but-ignoring-commas-in-quotes
                
                Movie M = new Movie(details[11],details[1],details[10],details[6],details[14],details[9],
                    details[8],details[16],details[23],details[17],details[21],details[20],
                    details[22],details[3],details[25], details[19]);
                    
                
                filmArr.add(M);
                

            }
            
        }  catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    
    /**
     * @param args
     */
    public static void main(String[] args) {
        getFromCSV();
        setQuestions();
        launch(args); // launch stage with javafx 
        
        
    }
}

