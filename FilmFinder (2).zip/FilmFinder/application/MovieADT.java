/**
 * MovieADT.java created by camro on CAM_PC in FilmFinder
 *
 * Author:	Cameron Rogers (cfrogers@wisc.edu)
 * Date:	@date
 * 
 * Course:	CS400
 * Year:	Spring 2020
 * Lecture: 002
 * 
 * IDE:		Eclipse IDE for Java Developers
 *
 * List Collaborators: Name, email@wisc.edu, lecture number
 *
 * Other credits: Other sources or info
 *
 * Known bugs: Describe unresolved errors
 */
package application;

/**
 * MovieADT - A simple data type for each movie
 * @author camro
 *
 */
public interface MovieADT {
    
}
